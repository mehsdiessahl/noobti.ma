# Noobti Site

## Hébergement Gratuit

### GitHub Pages
1. Crée un repository GitHub
2. Upload le dossier
3. Va dans Settings > Pages
4. Choisis:
   - Branch: main
   - Folder: /root
5. Save

### Netlify
1. Va sur https://app.netlify.com/drop
2. Glisse le dossier
3. Ton site sera en ligne
